package com.hongster.dis.common.model.system.ext;

import com.hongster.dis.common.model.system.SysHospital;

/**
 * 创建SysHospital的编辑实体，可增加一些编辑页面需要的实体
 * @date 2018/8/24.
 */
public class SysHospitalEdit extends SysHospital {

}
