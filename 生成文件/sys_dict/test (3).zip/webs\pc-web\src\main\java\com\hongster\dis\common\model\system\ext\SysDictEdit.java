package com.hongster.dis.common.model.system.ext;

import com.hongster.dis.common.model.system.SysDict;

/**
 * 创建SysDict的编辑实体，可增加一些编辑页面需要的实体
 * @date 2018/8/24.
 */
public class SysDictEdit extends SysDict {

}
