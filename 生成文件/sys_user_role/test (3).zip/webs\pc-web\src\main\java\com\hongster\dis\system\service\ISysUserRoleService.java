package com.hongster.dis.system.service;


import com.github.pagehelper.PageInfo;
import com.hongster.dis.common.model.system.SysUserRole;
import com.hongster.dis.common.model.system.SysUserRoleExample;
import com.hongster.dis.common.model.system.ext.SysUserRoleList;
import com.hongster.dis.common.model.system.ext.SysUserRoleEdit;
import org.apache.ibatis.session.RowBounds;

import java.util.List;


/**
 *  服务类实现
 */
public interface ISysUserRoleService{


    SysUserRole getByPrimaryKey(String id);

    /**
     * 不带分页
     */
    List<SysUserRole> selectByExample(SysUserRoleExample example);

    /**
     * 带分页
     */
    List<SysUserRole> selectByExampleWithRowbounds(SysUserRoleExample example, RowBounds rowBounds);

    void updateByPrimaryKey(SysUserRole model);

    void updateByPrimaryKeySelective(SysUserRole model);

    void deleteByPrimaryKey(String id);

    void deleteByPrimaryKeys(List<String> ids);

    void insert(SysUserRole model);

    //查询全部列表
    List<SysUserRoleList> listAll(SysUserRoleList sysUserRoleList);

    //查询列表分页方法
    PageInfo list(SysUserRoleList sysUserRoleList);

    //获取实体方法
    SysUserRoleEdit getInfo(String id);

    //保存实体方法
    int saveOrEdit(SysUserRoleEdit sysUserRoleEdit);

    //删除方法
    int delete(String[] ids);

}
