package com.hongster.dis.system.service.impl;

import com.github.pagehelper.PageInfo;
import com.hemodialysis.common.base.AbstractBaseServiceImpl;
import com.hemodialysis.common.exception.ServiceException;
import com.hemodialysis.common.sys.PageEntity;
import com.hongster.dis.system.dao.SysUserRoleMapper;
import com.hongster.dis.system.dao.ext.ExtSysUserRoleMapper;
import com.hongster.dis.common.model.system.SysUserRole;
import com.hongster.dis.common.model.system.SysUserRoleExample;
import com.hongster.dis.common.model.system.ext.SysUserRoleList;
import com.hongster.dis.common.model.system.ext.SysUserRoleEdit;
import com.hongster.dis.system.service.ISysUserRoleService;
import com.hemodialysis.common.util.ToolUtil;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 *  服务类实现
 */
@Service
public class SysUserRoleServiceImpl extends AbstractBaseServiceImpl implements ISysUserRoleService {
    private static final Logger logger = LoggerFactory.getLogger(SysUserRoleServiceImpl.class);


    @Autowired
    SysUserRoleMapper mapper;

    @Autowired
    ExtSysUserRoleMapper extSysUserRoleMapper;

    //<editor-fold desc="通用的接口">
    @Override
    public SysUserRole getByPrimaryKey(String id) {
        return mapper.selectByPrimaryKey(id);
    }

    /**
     * 带分页
     */
    @Override
    public List<SysUserRole> selectByExample(SysUserRoleExample example) {
        return mapper.selectByExample(example);
    }

    /**
     * 带分页
     */
    @Override
    public List<SysUserRole> selectByExampleWithRowbounds(SysUserRoleExample example, RowBounds rowBounds) {
        return mapper.selectByExampleWithRowbounds(example, rowBounds);
    }

    @Override
    public void updateByPrimaryKey(SysUserRole model) {
/*        if (model.getUpdateDate() == null)
        model.setUpdateDate(new Date().getTime());*/
        mapper.updateByPrimaryKey(model);
    }

    @Override
    public void updateByPrimaryKeySelective(SysUserRole model) {
/*        if (model.getUpdateDate() == null)
            model.setUpdateDate(new Date().getTime());*/
        mapper.updateByPrimaryKeySelective(model);
    }

    @Override
    public void deleteByPrimaryKey(String id) {
//        if(!canDel(id))
//            throw new ServiceException("id="+id+"的xx下面有xx不能删除,需要先删除所有xx才能删除");

        mapper.deleteByPrimaryKey(id);
    }

    @Override
    public void deleteByPrimaryKeys(List<String> ids) {
        if (ids != null && ids.size() > 0) {
//            if(!canDel(ids))
//                throw new ServiceException("xx下面有xx不能删除,需要先删除所有xx才能删除");

            SysUserRoleExample example = new SysUserRoleExample();
            SysUserRoleExample.Criteria criteria = example.createCriteria();
            criteria.andIdIn(ids);
            mapper.deleteByExample(example);

        }
    }

    @Override
    public void insert(SysUserRole model) {
/*        if (model.getCreateDate() == null) {
            model.setCreateDate(new Date().getTime());
        }*/
        mapper.insert(model);
    }

    /**
     * 查询全部列表方法
     * @param sysUserRoleList
     * @return
     */
    @Override
    public List<SysUserRoleList> listAll(SysUserRoleList sysUserRoleList) {
        List<SysUserRoleList> list=extSysUserRoleMapper.list(sysUserRoleList);
        return list;
    }

    /**
     * 分页查询列表方法
     * @param sysUserRoleList
     * @return
     */
    @Override
    public PageInfo list(SysUserRoleList sysUserRoleList) {
        List<SysUserRoleList> list=extSysUserRoleMapper.list(sysUserRoleList,
                new RowBounds(sysUserRoleList.getPage().getPageNum(),sysUserRoleList.getPage().getPageSize()));
        PageInfo pageInfo=new PageInfo(list);
        return pageInfo;
    }

    /**
     * 获取实体方法，可通过查询返回复杂实体到前台
     * 除了返回本记录实体，也可继续返回其他字段
     * @param id
     * @return
     */
    @Override
    public SysUserRoleEdit getInfo(String id) {
        SysUserRoleEdit sysUserRoleEdit=new SysUserRoleEdit();
        if(ToolUtil.isNotEmpty(id)){
            SysUserRole sysUserRole=mapper.selectByPrimaryKey(id);
            //字段相同时才能复制，排除个别业务字段请百度一下
            BeanUtils.copyProperties(sysUserRole,sysUserRoleEdit);
            //此处可继续返回其他字段...
        }
        return sysUserRoleEdit;
    }

    /**
     * 保存方法
     * @param sysUserRoleEdit
     * @return
     */
    @Override
    @Transactional
    public int saveOrEdit(SysUserRoleEdit sysUserRoleEdit) {
        int n=0;
        if(ToolUtil.isEmpty(sysUserRoleEdit.getId())){
            //id为空，新增操作
            sysUserRoleEdit.setId(ToolUtil.getUUID());
            n = mapper.insertSelective(sysUserRoleEdit);
        }else{
            //id不为空，编辑操作
            n = mapper.updateByPrimaryKeySelective(sysUserRoleEdit);
        }
        return n;
    }

    /**
     * 删除方法
     * @param ids
     * @return
     */
    @Override
    @Transactional
    public int delete(String[] ids) {
        if(ids!=null&&ids.length>0){
            //物理删除状态
            deleteByPrimaryKeys(Arrays.asList(ids));
        }
        return 0;
    }

}
